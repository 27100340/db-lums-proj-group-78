## you need node installed
## then navigate to frontend/serviceconnect-ui
## run following commans
npm install
npm run dev

# this should spawn a frontend on localhost:3000 
# note do this in a separate terminal while running backend in separate terminal